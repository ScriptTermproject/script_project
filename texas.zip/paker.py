from tkinter import *
from tkinter import font
from winsound import *
from Card import *
from Player import *
import random

class BlackJack:
    def __init__(self):
        self.window = Tk()
        self.window.title("Black Jack")
        self.window.geometry("800x600")
        self.window.configure(bg="green")
        self.fontstyle = font.Font(self.window, size=24, weight='bold', family='Consolas')
        self.fontstyle2 = font.Font(self.window, size=16, weight='bold', family='Consolas')
        self.setupButton()  #버튼 7개 성성
        self.setupLabel()  #라벨 5개 생성
        self.player = Player("player")
        self.dealer = Player("dealer")
        self.board=Player("board")
        self.betMoney = 10
        self.playerMoney = 990
        self.nCardsDealer = 0  #딜러카드 위치나타내는 인덱스
        self.nCardsPlayer = 0  #플레이어카드 위치 나타내는 인덱스
        self.nCardsBoard = 0
        self.LcardsPlayer = [] #카드이미지라벨 리스트
        self.LcardsDealer = []
        self.LcardsBoard = []
        self.deckN = 0 #카드덱에서 몇번째 카드를 가져올지 결저와는 인덱스
        self.window.mainloop()

    def setupButton(self):
        self.check = Button(self.window,text="check", width=6,height=1, font=self.fontstyle2,command=self.pressedcheck)
        self.check.place(x=50,y=500)
        self.B1 = Button(self.window,text="Bet x1", width=6,height=1, font=self.fontstyle2,command=self.pressedB1)
        self.B1.place(x=150,y=500)
        self.B2 = Button(self.window,text="Bet x2", width=6,height=1, font=self.fontstyle2,command=self.pressedB2)
        self.B2.place(x=250,y=500)
        self.Deal = Button(self.window,text="Deal", width=6,height=1, font=self.fontstyle2,command=self.pressedDeal)
        self.Deal.place(x=600,y=500)
        self.Again = Button(self.window,text="Again", width=6,height=1, font=self.fontstyle2,command=self.pressedAgain)
        self.Again.place(x=700,y=500)
        self.Deal['state'] = 'disabled'
        self.Deal['bg'] = 'gray'
        self.Again['state'] = 'disabled'
        self.Again['bg'] = 'gray'

    def setupLabel(self):
        self.LbetMoney = Label(text="$10",width=4,height=1,font=self.fontstyle,bg="green",fg="cyan")
        self.LbetMoney.place(x=200,y=450)
        self.LplayerMoney = Label(text="You have $990",width=15,height=1,font=self.fontstyle,bg="green",fg="cyan")
        self.LplayerMoney.place(x=500,y=450)
        self.LplayerPts = Label(text="",width=15,height=1,font=self.fontstyle2,bg="green",fg="white")
        self.LplayerPts.place(x=300,y=400)
        self.LdealerPts = Label(text="",width=15,height=1,font=self.fontstyle2,bg="green",fg="white")
        self.LdealerPts.place(x=300,y=100)
        self.Lstatus = Label(text="",width=15,height=1,font=self.fontstyle,bg="green",fg="white")
        self.Lstatus.place(x=500,y=350)

    def pressedB1(self):
        self.betMoney += self.betMoney
        if self.betMoney <= self.playerMoney:
            self.LbetMoney.configure(text="$" + str(self.betMoney))
            self.playerMoney -= self.betMoney//2
            self.LplayerMoney.configure(text="You have $" + str(self.playerMoney))
            PlaySound('sounds/chip.wav', SND_FILENAME)
        else:
            self.betMoney -= self.betMoney

    def pressedB2(self):
        self.betMoney += 2*self.betMoney
        if self.betMoney <= self.playerMoney:
            self.LbetMoney.configure(text="$" + str(self.betMoney))
            self.playerMoney -= 2*self.betMoney//3
            self.LplayerMoney.configure(text="You have $" + str(self.playerMoney))
            PlaySound('sounds/chip.wav', SND_FILENAME)
        else:
            self.betMoney -= 2*self.betMoney

    def pressedDeal(self):
        if self.player.inHand()==0:
            self.deal()
        else:
            self.boarddeal()

    def pressedAgain(self):
        self.player.reset()
        self.dealer.reset()  # 카드 덱 52장 셔플링 0,1,,.51
        self.board.reset()
        self.check['state'] = 'active'
        self.check['bg'] = 'white'
        self.B1['state'] = 'active'
        self.B1['bg'] = 'white'
        self.B2['state'] = 'active'
        self.B2['bg'] = 'white'

        self.Again['state'] = 'disabled'
        self.Again['bg'] = 'gray'
        self.LplayerPts.configure(text='')
        self.LdealerPts.configure(text='')
        self.Lstatus.configure(text='')
        for i in range(len(self.LcardsPlayer)):
            self.LcardsPlayer[i].destroy()
        for i in range(len(self.LcardsDealer)):
            self.LcardsDealer[i].destroy()
        for i in range(len(self.LcardsBoard)):
            self.LcardsBoard[i].destroy()
        self.LcardsDealer.clear()
        self.LcardsPlayer.clear()
        self.LcardsBoard.clear()

    def pressedcheck(self):
        self.check['state'] = 'disabled'
        self.check['bg'] = 'gray'
        self.B1['state'] = 'disabled'
        self.B1['bg'] = 'gray'
        self.B2['state'] = 'disabled'
        self.B2['bg'] = 'gray'
        self.Deal["state"] = "active"
        self.Deal["bg"] = "white"
        PlaySound('sounds/chip.wav', SND_FILENAME)

    def boarddeal(self):
        if self.board.inHand()==0:
            for i in range(2):
                self.hitboard(self.nCardsBoard)
        self.hitboard(self.nCardsBoard)
        self.check['state'] = 'active'
        self.check['bg'] = 'white'
        self.B1['state'] = 'active'
        self.B1['bg'] = 'white'
        self.B2['state'] = 'active'
        self.B2['bg'] = 'white'
        self.Deal['state'] = 'disabled'
        self.Deal['bg'] = 'gray'

    def hitboard(self,n):
        self.nCardsBoard += 1
        newCard = Card(self.cardDeck[self.deckN])
        self.deckN += 1
        self.board.addCard(newCard)
        p = PhotoImage(file="cards/" + newCard.filename())
        self.LcardsBoard.append(Label(self.window, image=p))
        # 파이썬은 라벨 이미지 레퍼런스를 갖고 있어야 이미지가 보임
        self.LcardsBoard[self.board.inHand() - 1].image = p
        self.LcardsBoard[self.board.inHand() - 1].place(x=150 + n * 80, y=225)
        PlaySound('sounds/cardFlip1.wav', SND_FILENAME)
        if self.board.inHand()==5:
            self.check['state'] = 'disabled'
            self.check['bg'] = 'gray'
            self.B1['state'] = 'disabled'
            self.B1['bg'] = 'gray'
            self.B2['state'] = 'disabled'
            self.B2['bg'] = 'gray'
            self.Deal['state'] = 'disabled'
            self.Deal['bg'] = 'gray'
            self.Again['state'] = 'active'
            self.Again['bg'] = 'white'
            self.checkWinner()

    def hitDealerDown(self,n):
        newCard = Card(self.cardDeck[self.deckN])
        self.deckN += 1
        self.dealer.addCard(newCard)
        p = PhotoImage(file="cards/b2fv.png")
        self.LcardsDealer.append(Label(self.window, image=p))
        self.LcardsDealer[self.dealer.inHand() - 1].image = p
        self.LcardsDealer[self.dealer.inHand() - 1].place(x=50 + n * 80, y=100)
        PlaySound('sounds/cardFlip1.wav', SND_FILENAME)

    def hitDealer(self,n):
        newCard = Card(self.cardDeck[self.deckN])
        self.deckN += 1
        self.dealer.addCard(newCard)
        self.nCardsDealer += 1
        p = PhotoImage(file="cards/" + newCard.filename())
        self.LcardsDealer.append(Label(self.window, image=p))
        # 파이썬은 라벨 이미지 레퍼런스를 갖고 있어야 이미지가 보임
        self.LcardsDealer[self.dealer.inHand() - 1].image = p
        self.LcardsDealer[self.dealer.inHand() - 1].place(x=50 + (n+1) * 80, y=100)
        PlaySound('sounds/cardFlip1.wav', SND_FILENAME)

    def deal(self):

        self.cardDeck = [i for i in range(52)]
        random.shuffle(self.cardDeck)
        self.deckN =0
        self.hitPlayer(0)  #0번 위치
        self.hitDealerDown(0)  #첫번째 카드 엎기
        self.hitDealerDown(1)
        self.hitPlayer(1)
        self.nCardsPlayer =1
        self.nCardsDealer =0
        self.nCardsBoard=0
        self.check['state'] = 'active'
        self.check['bg'] = 'white'
        self.B1['state'] = 'active'
        self.B1['bg'] = 'white'
        self.B2['state'] = 'active'
        self.B2['bg'] = 'white'
        self.Deal['state'] = 'disabled'
        self.Deal['bg'] = 'gray'

    def hitPlayer(self, n):  #카드의 위치를 나타내는 인자
        self.nCardsPlayer += 1
        newCard = Card(self.cardDeck[self.deckN])
        self.deckN += 1
        self.player.addCard(newCard)
        p = PhotoImage(file="cards/"+newCard.filename())
        self.LcardsPlayer.append(Label(self.window,image=p))
        #파이썬은 라벨 이미지 레퍼런스를 갖고 있어야 이미지가 보임
        self.LcardsPlayer[self.player.inHand() - 1].image = p
        self.LcardsPlayer[self.player.inHand() - 1].place(x=50+n*80,y=350)
        PlaySound('sounds/cardFlip1.wav', SND_FILENAME)


    def checkWinner(self):
        #뒤집힌 카드를 다시 그린다.
        p = PhotoImage(file="cards/"+self.dealer.cards[0].filename())
        self.LcardsDealer[0].configure(image = p) #이미지 레퍼런스 변경
        self.LcardsDealer[0].image=p#파이썬은 라벨 이미지 레퍼런스를 갖고 있어야 이미지가 보임
        p2 = PhotoImage(file="cards/" + self.dealer.cards[1].filename())
        self.LcardsDealer[1].configure(image=p2)  # 이미지 레퍼런스 변경
        self.LcardsDealer[1].image = p2

        boardcard=self.board.value()

        playernum=[]
        playercard=self.player.value()
        playernum.append([playercard[0].getValue(),playercard[0].getsuit()])
        playernum.append([playercard[1].getValue(),playercard[1].getsuit()])
        for i in range(5):
            playernum.append([boardcard[i].getValue(),boardcard[i].getsuit()])

        dealernum = []
        dealercard = self.dealer.value()
        dealernum.append([dealercard[0].getValue(),dealercard[0].getsuit()])
        dealernum.append([dealercard[1].getValue(),dealercard[1].getsuit()])
        for i in range(5):
            dealernum.append([boardcard[i].getValue(),boardcard[i].getsuit()])



        playertop=0
        dealertop=0

        playernum.sort(key=lambda x:(x[1],x[0]))
        playerscore=0


        for i in range(len(playernum)-3):
            if playernum[i][0]==10 and playernum[i+1][0]==11 and playernum[i+2][0]==12 and playernum[i+3][0]==13:
                shafe=playernum[i][1]
                if playernum[i+1][1]==playernum[i+2][1]==playernum[i+3][1]==shafe:
                    if [1,shafe] in playernum:
                        playerscore =max(playerscore, 12)  #로티플
                        break
                else:
                    if [1,"Clubs"] in playernum or [1,"Diamonds"] in playernum or [1,"Spades"] in playernum or [1,"Hearts"] in playernum:
                        playerscore =max(playerscore, 6)  #마운틴
                        break


        for i in range(len(playernum)-3):
                if playernum[i][0] == 1 and playernum[i+1][0] == 2 and playernum[i+2][0] == 3 and playernum[i+3][0] == 4 and playernum[i+4][0]==5:
                    shafe = playernum[i][1]
                    if playernum[i+1][1] == playernum[i+2][1] == playernum[i+3][1] == playernum[i+4][1]==shafe:
                        playerscore =max(playerscore, 11)  # 백스트플
                        break
                    else:
                        playerscore =max(playerscore, 5)  # 백스트레이트
                        break


        for i in range(len(playernum)-3):
                if playernum[i][0]==10:
                    if playernum[i+1][0] == playernum[i][0] + 1 and playernum[i+2][0] == playernum[i][0] + 2 and playernum[i+3][0] == playernum[i][0] + 3:
                        shafe = playernum[i][1]
                        if playernum[i+1][1] == playernum[i+2][1] == playernum[i+3][1]  == shafe:
                            if [1,shafe] in playernum:
                                if playerscore<10:
                                    playerscore=10
                                    playertop=1

                                break


                elif playernum[i][0]==11:
                    if playernum[i+1][0] == playernum[i][0] + 1 and playernum[i+2][0] == playernum[i][0] + 2 :
                        shafe = playernum[i][1]
                        if playernum[i+1][1] == playernum[i+2][1]  == shafe:
                            if [1,shafe] in playernum and [2,shafe] in playernum:
                                if playerscore < 10:
                                    playerscore = 10
                                    playertop = 1 #스트플
                                break

                elif playernum[i][0]==12:
                    if playernum[i+1][0] == playernum[i][0] + 1 :
                        shafe = playernum[i][1]
                        if playernum[i+1][1]  == shafe:
                            if [1,shafe] in playernum and [2,shafe] in playernum and [3,shafe] in playernum:
                                if playerscore < 10:
                                    playerscore = 10
                                    playertop = 1 #스트플
                                break

                elif playernum[i][0]==13:
                    shafe = playernum[i][1]
                    if [1, shafe] in playernum and [2, shafe] in playernum and [3, shafe] in playernum and [4,shafe] in playernum:
                        if playerscore < 10:
                            playerscore = 10
                            playertop = 1  # 스트플
                        break


        for i in range(len(playernum) - 4):
                    if playernum[i+1][0] == playernum[i][0]+1 and playernum[i+2][0] == playernum[i][0]+2 and playernum[i+3][0] == playernum[i][0]+3 and playernum[i+4][0]==playernum[i][0]+4:
                        shafe = playernum[i][1]
                        if playernum[i+1][1] == playernum[i+2][1] == playernum[i+3][1] == playernum[i+4][1]==shafe:
                            if playerscore < 10:
                                playerscore = 10
                                playertop = playernum[i+4][0]  # 스트플


        playernum.sort(key=lambda x: (x[0], x[1]))

        for i in range(len(playernum) - 3):
            if playernum[i][0] == 10:
                if playernum[i + 1][0] == playernum[i][0] + 1 and playernum[i + 2][0] == playernum[i][0] + 2 and \
                        playernum[i + 3][0] == playernum[i][0] + 3:
                    if [1, "Clubs"] in playernum or [1, "Diamonds"] in playernum or [1, "Spades"] in playernum or [1, "Hearts"] in playernum:
                            if playerscore < 4:
                                playerscore = 4
                                playertop = 1
                            break

            elif playernum[i][0] == 11:
                if playernum[i + 1][0] == playernum[i][0] + 1 and playernum[i + 2][0] == playernum[i][0] + 2:
                    if ([1, "Clubs"] in playernum or [1, "Diamonds"] in playernum or [1, "Spades"] in playernum or [
                            1, "Hearts"] in playernum) and (
                                [2, "Clubs"] in playernum or [2, "Diamonds"] in playernum or [2,
                                                                                              "Spades"] in playernum or [
                                    2, "Hearts"] in playernum):
                            if playerscore < 4:
                                playerscore = 4
                                playertop = 1
                            break
            elif playernum[i][0] == 12:
                if playernum[i + 1][0] == playernum[i][0] + 1:
                    if ([1, "Clubs"] in playernum or [1, "Diamonds"] in playernum or [1, "Spades"] in playernum or [
                            1, "Hearts"] in playernum) \
                                and ([2, "Clubs"] in playernum or [2, "Diamonds"] in playernum or [2,
                                                                                                   "Spades"] in playernum or [
                                         2, "Hearts"] in playernum) \
                                and ([3, "Clubs"] in playernum or [3, "Diamonds"] in playernum or [3,
                                                                                                   "Spades"] in playernum or [
                                         3, "Hearts"] in playernum):
                            if playerscore < 4:
                                playerscore = 4
                                playertop = 1
                            break
            elif playernum[i][0] == 13:
                if ([1, "Clubs"] in playernum or [1, "Diamonds"] in playernum or [1, "Spades"] in playernum or [1,"Hearts"] in playernum) \
                            and ([2, "Clubs"] in playernum or [2, "Diamonds"] in playernum or [2, "Spades"] in playernum or [2, "Hearts"] in playernum) \
                            and ([3, "Clubs"] in playernum or [3, "Diamonds"] in playernum or [3, "Spades"] in playernum or [3, "Hearts"] in playernum) \
                            and ([4, "Clubs"] in playernum or [4, "Diamonds"] in playernum or [4, "Spades"] in playernum or [4, "Hearts"] in playernum):
                        if playerscore < 4:
                            playerscore = 4
                            playertop = 1
                        break

        for i in range(len(playernum) - 4):
            if playernum[i + 1][0] == playernum[i][0] + 1 and playernum[i + 2][0] == playernum[i][0] + 2 and \
                    playernum[i + 3][0] == playernum[i][0] + 3 and playernum[i + 4][0] == playernum[i][0] + 4:
                if playerscore < 4:
                        playerscore = 4
                        playertop = playernum[i + 4][0]  # 스트레이트

        for i in range(len(playernum)-3):
                if playernum[i][0]==playernum[i+1][0]==playernum[i+2][0]==playernum[i+3][0]:
                    if playerscore < 9:
                        playerscore = 9
                        playertop = playernum[i + 3][0]
                    break

        num=0
        for i in range(len(playernum)-2):
                if playernum[i][0]==playernum[i+1][0]==playernum[i+2][0]:
                    num=playernum[i][0]
        if num!=0:
                for i in range(len(playernum)-1):
                    if playernum[i][0] !=num and playernum[i][0]==playernum[i+1][0]:
                        if playerscore < 8:
                            playerscore = 8
                            playertop = num
                        break

        playernum.sort(key=lambda x: (x[1], x[0]))


        for i in range(len(playernum)-4):
                if playernum[i][1]==playernum[i+1][1]==playernum[i+2][1]==playernum[i+3][1]==playernum[i+4][1]:
                    if playerscore < 7:
                        playerscore = 7
                        if playernum[i][0]==1 or playernum[i+1][0]==1 or playernum[i+2][0]==1 or playernum[i+3][0]==1 or playernum[i+4][0]==1:
                            playertop=1
                        else:
                            playertop = max(playernum[i][0],playernum[i+1][0],playernum[i+2][0],playernum[i+3][0],playernum[i+4][0])
                    break

        playernum.sort(key=lambda x: (x[0], x[1]))
        #트리플
        for i in range(len(playernum)-2):
            if playernum[i][0]==playernum[i+1][0]==playernum[i+2][0]:
                if playerscore < 3:
                    playerscore = 3
                    playertop = playernum[i][0]
                break

        sc=0
        for i in range(len(playernum)-1):
            if playernum[i][0]==playernum[i+1][0]:
                sc=playernum[i][0]
        if sc!=0:
            for i in range(len(playernum) - 1):
                if playernum[i][0]!=sc and playernum[i][0] == playernum[i + 1][0]:
                    if playerscore < 2:
                        playerscore = 2
                        if sc==1 or playernum[i][0]==1:
                            playertop=1
                        else:
                            playertop = max(sc,playernum[i][0])
                    break

        for i in range(len(playernum)-1):
            if playernum[i][0]==playernum[i+1][0]:
                if playerscore < 1:
                    playerscore = 1
                    playertop = playernum[i][0]
                break
        if playerscore==0:
            d=0
            for i in playernum:
                if i[0]==1:
                    d=1
                    break
                d=max(d,i[0])
            playertop=d




        dealernum.sort(key=lambda x: (x[1], x[0]))
        dealerscore = 0


        for i in range(len(dealernum) - 3):
            if dealernum[i][0] == 10 and dealernum[i + 1][0] == 11 and dealernum[i + 2][0] == 12 and dealernum[i + 3][0] == 13:
                shafe = dealernum[i][1]
                if dealernum[i + 1][1] == dealernum[i + 2][1] == dealernum[i + 3][1] == shafe:
                    if [1, shafe] in dealernum:
                        dealerscore= max(dealerscore, 12)  # 로티플
                        break
                else:
                    if [1, "Clubs"] in dealernum or [1, "Diamonds"] in dealernum or [1, "Spades"] in dealernum or [1,
                                                                                                                   "Hearts"] in dealernum:
                        dealerscore = max(dealerscore, 6)  # 마운틴
                        break

        for i in range(len(dealernum) - 3):
            if dealernum[i][0] == 1 and dealernum[i + 1][0] == 2 and dealernum[i + 2][0] == 3 and dealernum[i + 3][0] == 4 and dealernum[i + 4][0] == 5:
                shafe = dealernum[i][1]
                if dealernum[i + 1][1] == dealernum[i + 2][1] == dealernum[i + 3][1] == dealernum[i + 4][1] == shafe:
                    dealerscore = max(dealerscore, 11)  # 백스트플
                    break
                else:
                    dealerscore = max(dealerscore, 5)  # 백스트레이트
                    break

        for i in range(len(dealernum) - 3):
            if dealernum[i][0] == 10:
                if dealernum[i + 1][0] == dealernum[i][0] + 1 and dealernum[i + 2][0] == dealernum[i][0] + 2 and \
                        dealernum[i + 3][0] == dealernum[i][0] + 3:
                    shafe = dealernum[i][1]
                    if dealernum[i + 1][1] == dealernum[i + 2][1] == dealernum[i + 3][1] == shafe:
                        if [1, shafe] in dealernum:
                            if dealerscore < 10:
                                dealerscore = 10
                                dealertop = 1  # 스트플
                            break


            elif dealernum[i][0] == 11:
                if dealernum[i + 1][0] == dealernum[i][0] + 1 and dealernum[i + 2][0] == dealernum[i][0] + 2:
                    shafe = dealernum[i][1]
                    if dealernum[i + 1][1] == dealernum[i + 2][1] == shafe:
                        if [1, shafe] in dealernum and [2, shafe] in dealernum:
                            if dealerscore < 10:
                                dealerscore = 10
                                dealertop = 1  # 스트플
                            break

            elif dealernum[i][0] == 12:
                if dealernum[i + 1][0] == dealernum[i][0] + 1:
                    shafe = dealernum[i][1]
                    if dealernum[i + 1][1] == shafe:
                        if [1, shafe] in dealernum and [2, shafe] in dealernum and [3, shafe] in dealernum:
                            if dealerscore < 10:
                                dealerscore = 10
                                dealertop = 1  # 스트플
                            break

            elif dealernum[i][0] == 13:
                shafe = dealernum[i][1]
                if [1, shafe] in dealernum and [2, shafe] in dealernum and [3, shafe] in dealernum and [4,shafe] in dealernum:
                    if dealerscore < 10:
                        dealerscore = 10
                        dealertop = 1  # 스트플
                    break


        for i in range(len(dealernum) - 4):
            if dealernum[i + 1][0] == dealernum[i][0] + 1 and dealernum[i + 2][0] == dealernum[i][0] + 2 and \
                    dealernum[i + 3][0] == dealernum[i][0] + 3 and dealernum[i + 4][0] == dealernum[i][0] + 4:
                shafe = dealernum[i][1]
                if dealernum[i + 1][1] == dealernum[i + 2][1] == dealernum[i + 3][1] == dealernum[i + 4][1] == shafe:
                    if dealerscore < 10:
                        dealerscore = 10
                        dealertop = dealernum[i + 4][0]  # 스트플


        dealernum.sort(key=lambda x: (x[0], x[1]))

        for i in range(len(dealernum) - 3):
            if dealernum[i][0] == 10:
                if dealernum[i + 1][0] == dealernum[i][0] + 1 and dealernum[i + 2][0] == dealernum[i][0] + 2 and \
                        dealernum[i + 3][0] == dealernum[i][0] + 3:
                    shafe = dealernum[i][1]
                    if [1, "Clubs"] in dealernum or [1, "Diamonds"] in dealernum or [1, "Spades"] in dealernum or [1, "Hearts"] in dealernum:
                            if dealerscore < 4:
                                dealerscore = 4
                                dealertop = 1
                            break

            elif dealernum[i][0] == 11:
                if dealernum[i + 1][0] == dealernum[i][0] + 1 and dealernum[i + 2][0] == dealernum[i][0] + 2:
                    if ([1, "Clubs"] in dealernum or [1, "Diamonds"] in dealernum or [1, "Spades"] in dealernum or [1, "Hearts"] in dealernum)\
                                and ([2, "Clubs"] in dealernum or [2, "Diamonds"] in dealernum or [2, "Spades"] in dealernum or [2, "Hearts"] in dealernum):
                            if dealerscore < 4:
                                dealerscore = 4
                                dealertop = 1
                            break
            elif dealernum[i][0] == 12:
                if dealernum[i + 1][0] == dealernum[i][0] + 1:
                    if ([1, "Clubs"] in dealernum or [1, "Diamonds"] in dealernum or [1, "Spades"] in dealernum or [1, "Hearts"] in dealernum)\
                                and ([2, "Clubs"] in dealernum or [2, "Diamonds"] in dealernum or [2, "Spades"] in dealernum or [2, "Hearts"] in dealernum)\
                                and ([3, "Clubs"] in dealernum or [3, "Diamonds"] in dealernum or [3, "Spades"] in dealernum or [3, "Hearts"] in dealernum):
                            if dealerscore < 4:
                                dealerscore = 4
                                dealertop = 1
                            break
            elif dealernum[i][0] == 13:
                if ([1, "Clubs"] in dealernum or [1, "Diamonds"] in dealernum or [1, "Spades"] in dealernum or [1, "Hearts"] in dealernum)\
                                and ([2, "Clubs"] in dealernum or [2, "Diamonds"] in dealernum or [2, "Spades"] in dealernum or [2, "Hearts"] in dealernum)\
                                and ([3, "Clubs"] in dealernum or [3, "Diamonds"] in dealernum or [3, "Spades"] in dealernum or [3, "Hearts"] in dealernum)\
                                and ([4, "Clubs"] in dealernum or [4, "Diamonds"] in dealernum or [4, "Spades"] in dealernum or [4, "Hearts"] in dealernum):
                        if dealerscore < 4:
                            dealerscore = 4
                            dealertop = 1
                        break

        for i in range(len(dealernum) - 4):
            if dealernum[i + 1][0] == dealernum[i][0] + 1 and dealernum[i + 2][0] == dealernum[i][0] + 2 and \
                    dealernum[i + 3][0] == dealernum[i][0] + 3 and dealernum[i + 4][0] == dealernum[i][0] + 4:
                if dealerscore < 4:
                        dealerscore = 4
                        dealertop = dealernum[i + 4][0]  # 스트레이트

        for i in range(len(dealernum) - 3):
            if dealernum[i][0] == dealernum[i + 1][0] == dealernum[i + 2][0] == dealernum[i + 3][0]:
                if dealerscore < 9:
                    dealerscore = 9
                    dealertop = dealernum[i + 3][0]
                break

        num = 0
        for i in range(len(dealernum) - 2):
            if dealernum[i][0] == dealernum[i + 1][0] == dealernum[i + 2][0]:
                num = dealernum[i][0]
        if num != 0:
            for i in range(len(dealernum) - 1):
                if dealernum[i][0] != num and dealernum[i][0] == dealernum[i + 1][0]:
                    if dealerscore < 8:
                        dealerscore = 8
                        dealertop = num
                    break

        dealernum.sort(key=lambda x: (x[1], x[0]))

        for i in range(len(dealernum) - 4):
            if dealernum[i][1] == dealernum[i + 1][1] == dealernum[i + 2][1] == dealernum[i + 3][1] == dealernum[i + 4][1]:
                if dealerscore < 7:
                    dealerscore = 7
                    if dealernum[i][0] == 1 or dealernum[i + 1][0] == 1 or dealernum[i + 2][0] == 1 or dealernum[i + 3][0] == 1 or dealernum[i + 4][0] == 1:
                        dealertop = 1
                    else:
                        dealertop = max(dealernum[i][0], dealernum[i + 1][0], dealernum[i + 2][0], dealernum[i + 3][0],
                                        dealernum[i + 4][0])
                break

        dealernum.sort(key=lambda x: (x[0], x[1]))
        # 트리플
        for i in range(len(dealernum) - 2):
            if dealernum[i][0] == dealernum[i + 1][0] == dealernum[i + 2][0]:
                if dealerscore < 3:
                    dealerscore = 3
                    dealertop = dealernum[i][0]
                break

        sc = 0
        for i in range(len(dealernum) - 1):
            if dealernum[i][0] == dealernum[i + 1][0]:
                sc = dealernum[i][0]
        if sc != 0:
            for i in range(len(dealernum) - 1):
                if dealernum[i][0] != sc and dealernum[i][0] == dealernum[i + 1][0]:
                    if dealerscore < 2:
                        dealerscore = 2
                        if sc==1 or dealernum[i][0]==1:
                            dealertop=1
                        else:
                            dealertop = max(sc, dealernum[i][0])
                    break

        for i in range(len(dealernum) - 1):
            if dealernum[i][0] == dealernum[i + 1][0]:
                if dealerscore < 1:
                    dealerscore = 1
                    dealertop = dealernum[i][0]
                break

        if dealerscore==0:
            d=0
            for i in dealernum:
                if i[0]==1:
                    d=1
                    break
                d=max(d,i[0])
            dealertop=d

        if playertop==1:
            topstr='A'
        elif playertop==13:
            topstr='K'
        elif playertop==12:
            topstr='Q'
        elif playertop==11:
            topstr='J'
        else:
            topstr=str(playertop)

        if dealertop==1:
            top2str='A'
        elif dealertop==13:
            top2str='K'
        elif dealertop==12:
            top2str='Q'
        elif dealertop==11:
            top2str='J'
        else:
            top2str=str(dealertop)

        if playerscore==12:
            self.LplayerPts.configure(text='Royal straight flush')
        elif playerscore==11:
            self.LplayerPts.configure(text='back straight flush')
        elif playerscore==10:
            self.LplayerPts.configure(text=topstr+' straight flush')
        elif playerscore==9:
            self.LplayerPts.configure(text=topstr+' four card')
        elif playerscore==8:
            self.LplayerPts.configure(text=topstr+' full house')
        elif playerscore==7:
            self.LplayerPts.configure(text=topstr+' flush')
        elif playerscore==6:
            self.LplayerPts.configure(text='mountain')
        elif playerscore==5:
            self.LplayerPts.configure(text='back straight')
        elif playerscore==4:
            self.LplayerPts.configure(text=topstr+' straight')
        elif playerscore==3:
            self.LplayerPts.configure(text=topstr+' triple')
        elif playerscore==2:
            self.LplayerPts.configure(text=topstr+' two pair')
        elif playerscore==1:
            self.LplayerPts.configure(text=topstr+' one pair')
        else:
            self.LplayerPts.configure(text=topstr+' top')


        if dealerscore==12:
            self.LdealerPts.configure(text='Royal straight flush')
        elif dealerscore==11:
            self.LdealerPts.configure(text='back straight flush')
        elif dealerscore==10:
            self.LdealerPts.configure(text=top2str+' straight flush')
        elif dealerscore==9:
            self.LdealerPts.configure(text=top2str+' four card')
        elif dealerscore==8:
            self.LdealerPts.configure(text=top2str+' full house')
        elif dealerscore==7:
            self.LdealerPts.configure(text=top2str+' flush')
        elif dealerscore==6:
            self.LdealerPts.configure(text='mountain')
        elif dealerscore==5:
            self.LdealerPts.configure(text='back straight')
        elif dealerscore==4:
            self.LdealerPts.configure(text=top2str+' straight')
        elif dealerscore==3:
            self.LdealerPts.configure(text=top2str+' triple')
        elif dealerscore==2:
            self.LdealerPts.configure(text=top2str+' two pair')
        elif dealerscore==1:
            self.LdealerPts.configure(text=top2str+' one pair')
        else:
            self.LdealerPts.configure(text=top2str+' top')

        if playertop==1:
            playertop=14
        if dealertop==1:
            dealertop=14

        if dealerscore < playerscore:
            self.Lstatus.configure(text="You won!!")
            self.playerMoney += self.betMoney*2
            PlaySound('sounds/win.wav', SND_FILENAME)
        elif playerscore<dealerscore:
            self.Lstatus.configure(text="Sorry you lost!")
            PlaySound('sounds/wrong.wav', SND_FILENAME)
        else:
            if playertop<dealertop:
                self.Lstatus.configure(text="Sorry you lost!")
                PlaySound('sounds/wrong.wav', SND_FILENAME)
            elif dealertop<playertop:
                self.Lstatus.configure(text="You won!!")
                self.playerMoney += self.betMoney * 2
                PlaySound('sounds/win.wav', SND_FILENAME)
            else:
                self.Lstatus.configure(text="Push")
                self.playerMoney += self.betMoney

        self.betMoney = 10
        self.playerMoney-=10
        self.LplayerMoney.configure(text="You have $"+str(self.playerMoney))
        self.LbetMoney.configure(text="$"+str(self.betMoney))
        self.check['state'] = 'disabled'
        self.check['bg'] = 'gray'
        self.B1['state'] = 'disabled'
        self.B1['bg'] = 'gray'
        self.B2['state'] = 'disabled'
        self.B2['bg'] = 'gray'
        self.Deal['state'] = 'disabled'
        self.Deal['bg'] = 'gray'
        self.Again['state'] = 'active'
        self.Again['bg'] = 'white'

BlackJack()