class Player:
    def __init__(self, name):
        self.name = name
        self.cards = []   # card 클래스 객체를 갖는 리스트
        self.N = 0    #현재 갖고있는 카드수
    def inHand(self):    #갖고 있는 카드개수 반환
        return self.N
    def addCard(self,c):  #카드 추가
        self.cards.append(c)
        self.N += 1
    def reset(self):  #deal눌렀을때 초기화, 다시 나눠줌
        self.N = 0
        self.cards.clear()
    def value(self):            #ace는 1혹은 11로 모두 사용 가능 일단 11로 계산한 후 21이 넘어가면 1로 정정
        return self.cards