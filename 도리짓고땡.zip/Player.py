class Player:
    def __init__(self, name):
        self.name = name
        self.cards = []   # card 클래스 객체를 갖는 리스트
        self.N = 0    #현재 갖고있는 카드수
        self.made=''
        self.lst2=[]
    def inHand(self):    #갖고 있는 카드개수 반환
        return self.N
    def addCard(self,c):  #카드 추가
        self.cards.append(c)
        self.N += 1
    def getcard(self):
        return self.cards
    def reset(self):  #deal눌렀을때 초기화, 다시 나눠줌
        self.N = 0
        self.cards.clear()
        self.made=''
    def value(self):            #ace는 1혹은 11로 모두 사용 가능 일단 11로 계산한 후 21이 넘어가면 1로 정정
        lst=[]
        for i in range(self.inHand()):
            lst.append(self.cards[i].getValue())
        if lst.count(1)>=2 and 8 in lst:
            self.made='콩콩팔'
            lst.remove(1)
            lst.remove(1)
            lst.remove(8)
            self.lst2=[1,1,8]
        if 1 in lst and self.made=='':
            if 2 in lst and 7 in lst:
                self.made = '삐리칠'
                lst.remove(1)
                lst.remove(2)
                lst.remove(7)
                self.lst2 = [1, 2, 7]
            elif 3 in lst and 6 in lst:
                self.made = '물삼육'
                lst.remove(1)
                lst.remove(3)
                lst.remove(6)
                self.lst2 = [1, 3, 6]
            elif 4 in lst and 5 in lst:
                self.made = '빽세오'
                lst.remove(1)
                lst.remove(4)
                lst.remove(5)
                self.lst2 = [1, 4, 5]
            elif 9 in lst and 10 in lst:
                self.made = '삥구장'
                lst.remove(1)
                lst.remove(9)
                lst.remove(10)
                self.lst2 = [1, 9, 10]
        if 2 in lst and self.made == '':
            if lst.count(2)>=2 and 6 in lst:
                self.made = '니니육'
                lst.remove(2)
                lst.remove(2)
                lst.remove(6)
                self.lst2 = [2, 2, 6]
            elif 3 in lst and 5 in lst:
                self.made = '이삼오'
                lst.remove(2)
                lst.remove(3)
                lst.remove(5)
                self.lst2 = [2, 3, 5]
            elif lst.count(4)>=2:
                self.made = '살살이'
                lst.remove(2)
                lst.remove(4)
                lst.remove(4)
                self.lst2 = [2, 4, 4]
            elif 8 in lst and 10 in lst:
                self.made = '이판장'
                lst.remove(2)
                lst.remove(8)
                lst.remove(10)
                self.lst2 = [2, 8, 10]
            elif lst.count(9)>=2:
                self.made = '구구리'
                lst.remove(2)
                lst.remove(9)
                lst.remove(9)
                self.lst2 = [2, 9, 9]
        if 3 in lst and self.made == '':
            if lst.count(3)>=2 and 4 in lst:
                self.made = '심심새'
                lst.remove(3)
                lst.remove(3)
                lst.remove(4)
                self.lst2 = [3, 3, 4]
            elif 7 in lst and 10 in lst:
                self.made = '삼칠장'
                lst.remove(3)
                lst.remove(7)
                lst.remove(10)
                self.lst2 = [3, 7, 10]
            elif 8 in lst and 9 in lst:
                self.made = '삼빡구'
                lst.remove(3)
                lst.remove(8)
                lst.remove(9)
                self.lst2 = [3, 8, 9]
        if 4 in lst and self.made == '':
            if 6 in lst and 10 in lst:
                self.made = '사륙장'
                lst.remove(4)
                lst.remove(6)
                lst.remove(10)
                self.lst2 = [4, 6, 10]
            elif 7 in lst and 9 in lst:
                self.made = '사칠구'
                lst.remove(4)
                lst.remove(7)
                lst.remove(9)
                self.lst2 = [4, 7, 9]
            elif lst.count(8)>=2:
                self.made = '팍팍사'
                lst.remove(4)
                lst.remove(8)
                lst.remove(8)
                self.lst2 = [4, 8, 8]
        if 5 in lst and self.made == '':
            if lst.count(5)>=2 and 10 in lst:
                self.made = '꼬꼬장'
                lst.remove(5)
                lst.remove(5)
                lst.remove(10)
                self.lst2 = [5, 5, 10]
            elif 6 in lst and 9 in lst:
                self.made = '오륙구'
                lst.remove(5)
                lst.remove(6)
                lst.remove(9)
                self.lst2 = [5, 6, 9]
            elif 7 in lst and 8 in lst:
                self.made = '오리발'
                lst.remove(5)
                lst.remove(7)
                lst.remove(8)
                self.lst2 = [5, 7, 8]
        if 6 in lst and self.made == '':
            if lst.count(6)>=2 and 8 in lst:
                self.made = '쭉쭉팔'
                lst.remove(6)
                lst.remove(6)
                lst.remove(8)
                self.lst2 = [6, 6, 8]
            elif lst.count(7)>=2:
                self.made = '철철육'
                lst.remove(6)
                lst.remove(7)
                lst.remove(7)
                self.lst2 = [6, 7, 7]
        if self.made=='':
            self.made='노 메이드'
        if 1 in lst:
            for i in range(5):
                if self.cards[i].filename()=='1.1.gif':
                    lst.remove(1)
                    lst.append(1.5)
        if 3 in lst:
            for i in range(5):
                if self.cards[i].filename()=='3.1.gif':
                    lst.remove(3)
                    lst.append(3.5)
        if 8 in lst:
            for i in range(5):
                if self.cards[i].filename()=='8.1.gif':
                    lst.remove(8)
                    lst.append(8.5)

        return lst
    def Made(self):
        return self.made
    def Lst(self):
        return self.lst2