class Card:
    def __init__(self,temp):#렌덤 넘버0..39 값을 입력받아서 카드 객체 생성
        self.value = temp%10 + 1 #1..10
        self.x = temp//10 #0..3
    def getValue(self): #카드 값 JQK는 10으로 결정
        return self.value
    def getsuit(self): #카드 무늬 결정
        return (self.x)+1
    def filename(self): #카드 이미지 파일 이름
        return str(self.value)+'.'+str(self.getsuit())+".gif"