from tkinter import *
from tkinter import font
from winsound import *
from Card import *
from Player import *
import random

class BlackJack:
    def __init__(self):
        self.window = Tk()
        self.window.title("Black Jack")
        self.window.geometry("800x600")
        self.window.configure(bg="green")
        self.fontstyle = font.Font(self.window, size=24, weight='bold', family='Consolas')
        self.fontstyle2 = font.Font(self.window, size=16, weight='bold', family='Consolas')
        self.setupButton()  #버튼 7개 성성
        self.setupLabel()  #라벨 5개 생성
        self.player=[]
        for i in range(3):
            self.player.append( Player("player"+str(i+1)))

        self.dealer = Player("dealer")
        self.betMoney1 = 0
        self.betMoney2 = 0
        self.betMoney3 = 0
        self.playerMoney = 1000
        self.nCardsDealer = 0  #딜러카드 위치나타내는 인덱스
        self.nCardsPlayer = [0]*3  #플레이어카드 위치 나타내는 인덱스
        self.LcardsPlayer1 = [] #카드이미지라벨 리스트
        self.LcardsPlayer2 = []
        self.LcardsPlayer3 = []

        self.LcardsDealer = []
        self.deckN = 0 #카드덱에서 몇번째 카드를 가져올지 결저와는 인덱스
        self.window.mainloop()

    def setupButton(self):
        self.p1_5 = Button(self.window,text="5만", width=6,height=1, font=self.fontstyle2,
                           command=self.p15)
        self.p1_5.place(x=10,y=500)
        self.p1_1 = Button(self.window, text="1만", width=6, height=1, font=self.fontstyle2,
                           command=self.p11)
        self.p1_1.place(x=100, y=500)
        self.p2_5 = Button(self.window, text="5만", width=6, height=1, font=self.fontstyle2,
                           command=self.p25)
        self.p2_5.place(x=210, y=500)
        self.p2_1 = Button(self.window, text="1만", width=6, height=1, font=self.fontstyle2,
                           command=self.p21)
        self.p2_1.place(x=300, y=500)
        self.p3_5 = Button(self.window, text="5만", width=6, height=1, font=self.fontstyle2,
                           command=self.p35)
        self.p3_5.place(x=410, y=500)
        self.p3_1 = Button(self.window, text="1만", width=6, height=1, font=self.fontstyle2,
                           command=self.p31)
        self.p3_1.place(x=500, y=500)


        self.Deal = Button(self.window,text="Deal", width=6,height=1, font=self.fontstyle2,command=self.pressedDeal)
        self.Deal.place(x=600,y=500)
        self.Again = Button(self.window,text="Again", width=6,height=1, font=self.fontstyle2,command=self.pressedAgain)
        self.Again.place(x=700,y=500)

        self.Deal['state'] = 'disabled'
        self.Deal['bg'] = 'gray'
        self.Again['state'] = 'disabled'
        self.Again['bg'] = 'gray'

    def setupLabel(self):
        self.LbetMoney1 = Label(text="$0",width=4,height=1,font=self.fontstyle,bg="green",fg="cyan")
        self.LbetMoney1.place(x=55,y=450)
        self.LbetMoney2 = Label(text="$0", width=4, height=1, font=self.fontstyle, bg="green", fg="cyan")
        self.LbetMoney2.place(x=255, y=450)
        self.LbetMoney3 = Label(text="$0", width=4, height=1, font=self.fontstyle, bg="green", fg="cyan")
        self.LbetMoney3.place(x=455, y=450)

        self.LplayerMoney = Label(text="$1000",width=15,height=1,font=self.fontstyle,bg="green",fg="cyan")
        self.LplayerMoney.place(x=550,y=450)

        self.LplayerPts1 = []
        for i in range(5):
            self.LplayerPts1.append(Label(text="",width=2,height=1,font=self.fontstyle2,bg="green",fg="cyan"))
            self.LplayerPts1[i].place(x=30+i*30,y=270)

        self.LplayerPts2 = []
        for i in range(5):
            self.LplayerPts2.append(Label(text="", width=2, height=1, font=self.fontstyle2, bg="green", fg="cyan"))
            self.LplayerPts2[i].place(x=280 + i * 30, y=270)

        self.LplayerPts3 = []
        for i in range(5):
            self.LplayerPts3.append(Label(text="", width=2, height=1, font=self.fontstyle2, bg="green", fg="cyan"))
            self.LplayerPts3[i].place(x=530 + i * 30, y=270)

        self.LdealerPts = []
        for i in range(5):
            self.LdealerPts.append(Label(text="", width=2, height=1, font=self.fontstyle2, bg="green", fg="cyan"))
            self.LdealerPts[i].place(x=320+ i * 30, y=180)

        self.win=[] #승패
        for i in range(3):
            self.win.append(Label(text="",width=2,height=1,font=self.fontstyle2,bg="green",fg="red"))
            self.win[i].place(x=20+i*250,y=230)

        self.Lstatus=[] #메이드
        for i in range(3):
            self.Lstatus.append(Label(text="",width=8,height=1,font=self.fontstyle2,bg="green",fg="cyan"))
            self.Lstatus[i].place(x=50+i*250,y=230)

        self.value=[] #족보
        for i in range(3):
            self.value.append(Label(text="",width=7,height=1,font=self.fontstyle2,bg="green",fg="cyan"))
            self.value[i].place(x=160+i*250,y=230)

        self.dealerstatus=Label(text="", width=8, height=1, font=self.fontstyle2, bg="green", fg="cyan")
        self.dealerstatus.place(x=10, y=100)

        self.dealervalue=Label(text="", width=7, height=1, font=self.fontstyle2, bg="green", fg="cyan")
        self.dealervalue.place(x=130, y=100)

    def pressedDeal(self):
        if self.player[0].inHand()==0:
            self.deal()
        elif self.player[0].inHand()==1:
            self.seconddeal()
        else:
            self.thirddeal()

    def pressedAgain(self):
        for i in range(3):
            self.player[i].reset()
        self.dealer.reset()  # 카드 덱 40장 셔플링 0,1,,.51
        self.p1_1['state'] = 'active'
        self.p1_1['bg'] = 'white'
        self.p2_1['state'] = 'active'
        self.p2_1['bg'] = 'white'
        self.p3_1['state'] = 'active'
        self.p3_1['bg'] = 'white'
        self.p1_5['state'] = 'active'
        self.p1_5['bg'] = 'white'
        self.p2_5['state'] = 'active'
        self.p2_5['bg'] = 'white'
        self.p3_5['state'] = 'active'
        self.p3_5['bg'] = 'white'

        self.Again['state'] = 'disabled'
        self.Again['bg'] = 'gray'
        for i in range(5):
            self.LplayerPts1[i].configure(text='',fg='cyan')
            self.LplayerPts2[i].configure(text='',fg='cyan')
            self.LplayerPts3[i].configure(text='',fg='cyan')
        for i in range(5):
            self.LdealerPts[i].configure(text='',fg='cyan')
        for i in range(3):
            self.Lstatus[i].configure(text='')
            self.win[i].configure(text='')
            self.value[i].configure(text='')
        self.dealervalue.configure(text='')
        self.dealerstatus.configure(text='')
        for i in range(len(self.LcardsPlayer1)):
            self.LcardsPlayer1[i].destroy()
        for i in range(len(self.LcardsPlayer2)):
            self.LcardsPlayer2[i].destroy()
        for i in range(len(self.LcardsPlayer3)):
            self.LcardsPlayer3[i].destroy()
        for i in range(len(self.LcardsDealer)):
            self.LcardsDealer[i].destroy()
        self.LcardsDealer.clear()
        self.LcardsPlayer1.clear()
        self.LcardsPlayer2.clear()
        self.LcardsPlayer3.clear()
        self.nCardsDealer = 0
        self.nCardsPlayer = [0] * 3

    def p15(self):
        self.betMoney1 += 5
        if self.betMoney1 <= self.playerMoney:
            self.LbetMoney1.configure(text="$" + str(self.betMoney1))
            self.playerMoney -= 5
            self.LplayerMoney.configure(text="$" + str(self.playerMoney))
            PlaySound('sounds/chip.wav', SND_FILENAME)
        else:
            self.betMoney1 -= 5
        if self.betMoney1!= 0 and self.betMoney2!= 0 and self.betMoney3!= 0:
            self.Deal['state'] = 'active'
            self.Deal['bg'] = 'white'

    def p11(self):
        self.betMoney1 += 1
        if self.betMoney1 <= self.playerMoney:
            self.LbetMoney1.configure(text="$" + str(self.betMoney1))
            self.playerMoney -= 1
            self.LplayerMoney.configure(text="$" + str(self.playerMoney))
            PlaySound('sounds/chip.wav', SND_FILENAME)
        else:
            self.betMoney1 -= 1
        if self.betMoney1!= 0 and self.betMoney2!= 0 and self.betMoney3!= 0:
            self.Deal['state'] = 'active'
            self.Deal['bg'] = 'white'

    def p25(self):
        self.betMoney2 += 5
        if self.betMoney2 <= self.playerMoney:
            self.LbetMoney2.configure(text="$" + str(self.betMoney2))
            self.playerMoney -= 5
            self.LplayerMoney.configure(text="$" + str(self.playerMoney))
            PlaySound('sounds/chip.wav', SND_FILENAME)
        else:
            self.betMoney2 -= 5
        if self.betMoney1!= 0 and self.betMoney2!= 0 and self.betMoney3!= 0:
            self.Deal['state'] = 'active'
            self.Deal['bg'] = 'white'

    def p21(self):
        self.betMoney2 += 1
        if self.betMoney2 <= self.playerMoney:
            self.LbetMoney2.configure(text="$" + str(self.betMoney2))
            self.playerMoney -= 1
            self.LplayerMoney.configure(text="$" + str(self.playerMoney))
            PlaySound('sounds/chip.wav', SND_FILENAME)
        else:
            self.betMoney2 -= 1
        if self.betMoney1!= 0 and self.betMoney2!= 0 and self.betMoney3!= 0:
            self.Deal['state'] = 'active'
            self.Deal['bg'] = 'white'

    def p35(self):
        self.betMoney3 += 5
        if self.betMoney3 <= self.playerMoney:
            self.LbetMoney3.configure(text="$" + str(self.betMoney3))
            self.playerMoney -= 5
            self.LplayerMoney.configure(text="$" + str(self.playerMoney))
            PlaySound('sounds/chip.wav', SND_FILENAME)
        else:
            self.betMoney3 -= 5
        if self.betMoney1!= 0 and self.betMoney2!= 0 and self.betMoney3!= 0:
            self.Deal['state'] = 'active'
            self.Deal['bg'] = 'white'

    def p31(self):
        self.betMoney3 += 1
        if self.betMoney3 <= self.playerMoney:
            self.LbetMoney3.configure(text="$" + str(self.betMoney3))
            self.playerMoney -= 1
            self.LplayerMoney.configure(text="$" + str(self.playerMoney))
            PlaySound('sounds/chip.wav', SND_FILENAME)
        else:
            self.betMoney3 -= 1
        if self.betMoney1!= 0 and self.betMoney2!= 0 and self.betMoney3!= 0:
            self.Deal['state'] = 'active'
            self.Deal['bg'] = 'white'

    def hitDealerDown(self,n):
        newCard = Card(self.cardDeck[self.deckN])
        self.deckN += 1
        self.dealer.addCard(newCard)
        self.nCardsDealer += 1
        p = PhotoImage(file="cards/cardback.gif")
        self.LcardsDealer.append(Label(self.window, image=p))
        self.LcardsDealer[self.dealer.inHand() - 1].image = p
        self.LcardsDealer[self.dealer.inHand() - 1].place(x=300 + n * 30, y=70)
        PlaySound('sounds/cardFlip1.wav', SND_FILENAME)

    def hitDealer(self,n):
        newCard = Card(self.cardDeck[self.deckN])
        self.deckN += 1
        self.dealer.addCard(newCard)
        self.nCardsDealer += 1
        p = PhotoImage(file="cards/" + newCard.filename())
        self.LcardsDealer.append(Label(self.window, image=p))
        # 파이썬은 라벨 이미지 레퍼런스를 갖고 있어야 이미지가 보임
        self.LcardsDealer[self.dealer.inHand() - 1].image = p
        self.LcardsDealer[self.dealer.inHand() - 1].place(x=50 + (n+1) * 30, y=100)
        PlaySound('sounds/cardFlip1.wav', SND_FILENAME)

    def thirddeal(self):
        self.hitPlayer(self.nCardsPlayer[0])  # 0번 위치
        self.Deal['state'] = 'disabled'
        self.Deal['bg'] = 'gray'
        self.hitDealerDown(self.nCardsDealer)
        self.checkWinner()

    def seconddeal(self):
        for i in range(3):
            self.hitPlayer(self.nCardsPlayer[i])  # 0번 위치
        self.Deal['state'] = 'disabled'
        self.Deal['bg'] = 'gray'
        self.hitDealerDown(self.nCardsDealer)  # 첫번째 카드 엎기
        self.hitDealerDown(self.nCardsDealer)
        self.hitDealerDown(self.nCardsDealer)

    def deal(self):

        self.cardDeck = [i for i in range(40)]
        random.shuffle(self.cardDeck)
        self.deckN =0
        self.hitPlayer(0)  #0번 위치
        self.hitDealerDown(0)  #첫번째 카드 엎기
        self.Deal['state'] = 'disabled'
        self.Deal['bg'] = 'gray'

    def hitPlayer(self, n):
        for i in range(3):
            self.nCardsPlayer[i] += 1
            newCard = Card(self.cardDeck[self.deckN])
            self.deckN += 1
            self.player[i].addCard(newCard)
            p = PhotoImage(file="cards/"+newCard.filename())
            if i==0:
                self.LcardsPlayer1.append(Label(self.window,image=p))
                #파이썬은 라벨 이미지 레퍼런스를 갖고 있어야 이미지가 보임
                self.LcardsPlayer1[self.player[i].inHand() - 1].image = p
                self.LcardsPlayer1[self.player[i].inHand() - 1].place(x=10+n*30,y=320)
                self.LplayerPts1[self.player[i].inHand() - 1].configure(text=newCard.getValue())
            elif i==1:
                self.LcardsPlayer2.append(Label(self.window, image=p))
                self.LcardsPlayer2[self.player[i].inHand() - 1].image = p
                self.LcardsPlayer2[self.player[i].inHand() - 1].place(x=260 + n * 30, y=320)
                self.LplayerPts2[self.player[i].inHand() - 1].configure(text=newCard.getValue())
            else:
                self.LcardsPlayer3.append(Label(self.window, image=p))
                self.LcardsPlayer3[self.player[i].inHand() - 1].image = p
                self.LcardsPlayer3[self.player[i].inHand() - 1].place(x=510 + n * 30, y=320)
                self.LplayerPts3[self.player[i].inHand() - 1].configure(text=newCard.getValue())

            PlaySound('sounds/cardFlip1.wav', SND_FILENAME)


    def checkWinner(self):
        #뒤집힌 카드를 다시 그린다.
        for i in range(5):
            p = PhotoImage(file="cards/"+self.dealer.cards[i].filename())
            self.LcardsDealer[i].configure(image = p) #이미지 레퍼런스 변경
            self.LcardsDealer[i].image=p#파이썬은 라벨 이미지 레퍼런스를 갖고 있어야 이미지가 보임
            self.LdealerPts[i].configure(text=self.dealer.getcard()[i].getValue())

        plyervalue=[] #족보 계산
        playermade=[] #메이드
        for i in range(3):
            plyervalue.append(self.player[i].value())
            playermade.append(self.player[i].Lst())
            self.Lstatus[i].configure(text=self.player[i].Made())
        dealervalue=self.dealer.value()
        dealermade=self.dealer.Lst()
        self.dealerstatus.configure(text=self.dealer.Made())

        for j in range(5):
            if self.player[0].getcard()[j].getValue()  in playermade[0]:
                self.LplayerPts1[j].configure(fg='yellow')
                playermade[0].remove(self.player[0].getcard()[j].getValue())
            if self.player[1].getcard()[j].getValue()  in playermade[1]:
                self.LplayerPts2[j].configure(fg='yellow')
                playermade[1].remove(self.player[1].getcard()[j].getValue())
            if self.player[2].getcard()[j].getValue()  in playermade[2]:
                self.LplayerPts3[j].configure(fg='yellow')
                playermade[2].remove(self.player[2].getcard()[j].getValue())
            if self.dealer.getcard()[j].getValue() in dealermade:
                self.LdealerPts[j].configure(fg='yellow')
                dealermade.remove(self.dealer.getcard()[j].getValue())


        playerscore=[0]*3
        dealerscore=0
        for i in range(3):
            if len(plyervalue[i])!=5:
                if 3.5 in plyervalue[i] and 8.5 in plyervalue[i]:
                    playerscore[i]=4
                    self.value[i].configure(text='38 광땡')
                elif (1.5 in plyervalue[i] and 8.5 in plyervalue[i]) or (1.5 in plyervalue[i] and 3.5 in plyervalue[i]):
                    playerscore[i]=3
                    self.value[i].configure(text='광땡')
                elif plyervalue[i][0] == plyervalue[i][1] or plyervalue[i][0] == plyervalue[i][1]-0.5:
                    playerscore[i] = 2+(plyervalue[i][0]-1)/10
                    if plyervalue[i][0]==1:
                        self.value[i].configure(text='삥땡')
                    elif plyervalue[i][0]==2:
                        self.value[i].configure(text='이땡')
                    elif plyervalue[i][0]==3:
                        self.value[i].configure(text='삼땡')
                    elif plyervalue[i][0]==4:
                        self.value[i].configure(text='사땡')
                    elif plyervalue[i][0]==5:
                        self.value[i].configure(text='오땡')
                    elif plyervalue[i][0]==6:
                        self.value[i].configure(text='육땡')
                    elif plyervalue[i][0]==7:
                        self.value[i].configure(text='칠땡')
                    elif plyervalue[i][0]==8:
                        self.value[i].configure(text='팔땡')
                    elif plyervalue[i][0]==9:
                        self.value[i].configure(text='구땡')
                    elif plyervalue[i][0]==10:
                        self.value[i].configure(text='장땡')
                else:
                    if plyervalue[i][1]*10%10==5:
                        playerscore[i] = 1 + (plyervalue[i][0] + plyervalue[i][1]-0.5) % 10 / 10
                    else:
                        playerscore[i]=1+(plyervalue[i][0] + plyervalue[i][1])%10/10
                    if playerscore[i]==1.9:
                        self.value[i].configure(text='아홉 끗')
                    elif playerscore[i]==1.8:
                        self.value[i].configure(text='여덟 끗')
                    elif playerscore[i]==1.7:
                        self.value[i].configure(text='일곱 끗')
                    elif playerscore[i]==1.6:
                        self.value[i].configure(text='여섯 끗')
                    elif playerscore[i]==1.5:
                        self.value[i].configure(text='다섯 끗')
                    elif playerscore[i]==1.4:
                        self.value[i].configure(text='네 끗')
                    elif playerscore[i]==1.3:
                        self.value[i].configure(text='세 끗')
                    elif playerscore[i]==1.2:
                        self.value[i].configure(text='두 끗')
                    elif playerscore[i]==1.1:
                        self.value[i].configure(text='한 끗')
                    elif playerscore[i]==1.0:
                        self.value[i].configure(text='망통')
        if len(dealervalue)!=5:
            if 3.5 in dealervalue and 8.5 in dealervalue:
                dealerscore = 4
                self.dealervalue.configure(text='38 광땡')
            elif (1.5 in dealervalue and 8.5 in dealervalue) or (1.5 in dealervalue and 3.5 in dealervalue):
                dealerscore = 3
                self.dealervalue.configure(text='광땡')
            elif dealervalue[0] == dealervalue[1] or dealervalue[0] == dealervalue[1]-0.5:
                dealerscore = 2 + (dealervalue[0] - 1) / 10
                if dealervalue[0] == 1:
                    self.dealervalue.configure(text='삥땡')
                elif dealervalue[0] == 2:
                    self.dealervalue.configure(text='이땡')
                elif dealervalue[0] == 3:
                    self.dealervalue.configure(text='삼땡')
                elif dealervalue[0]== 4:
                    self.dealervalue.configure(text='사땡')
                elif dealervalue[0] == 5:
                    self.dealervalue.configure(text='오땡')
                elif dealervalue[0] == 6:
                    self.dealervalue.configure(text='육땡')
                elif dealervalue[0] == 7:
                    self.dealervalue.configure(text='칠땡')
                elif dealervalue[0] == 8:
                    self.dealervalue.configure(text='팔땡')
                elif dealervalue[0] == 9:
                    self.dealervalue.configure(text='구땡')
                elif dealervalue[0] == 10:
                    self.dealervalue.configure(text='장땡')
            else:
                if dealervalue[1] * 10 % 10 == 5:
                    dealerscore = 1 + (dealervalue[0] + dealervalue[1] - 0.5) % 10 / 10
                else:
                    dealerscore = 1 + (dealervalue[0] + dealervalue[1]) % 10 / 10
                if dealerscore == 1.9:
                    self.dealervalue.configure(text='아홉 끗')
                elif dealerscore == 1.8:
                    self.dealervalue.configure(text='여덟 끗')
                elif dealerscore == 1.7:
                    self.dealervalue.configure(text='일곱 끗')
                elif dealerscore == 1.6:
                    self.dealervalue.configure(text='여섯 끗')
                elif dealerscore == 1.5:
                    self.dealervalue.configure(text='다섯 끗')
                elif dealerscore == 1.4:
                    self.dealervalue.configure(text='네 끗')
                elif dealerscore == 1.3:
                    self.dealervalue.configure(text='세 끗')
                elif dealerscore == 1.2:
                    self.dealervalue.configure(text='두 끗')
                elif dealerscore == 1.1:
                    self.dealervalue.configure(text='한 끗')
                elif dealerscore == 1.0:
                    self.dealervalue.configure(text='망통')

        flag=[0,0,0]
        for i in range(3):
            if len(plyervalue[i])>len(dealervalue):
                self.win[i].configure(text="패")
                flag[i]=-1

            elif len(plyervalue[i])<len(dealervalue):
                self.win[i].configure(text="승")
                if i==0:
                    self.playerMoney += self.betMoney1 * 2
                elif i==1:
                    self.playerMoney += self.betMoney1 * 2
                else:
                    self.playerMoney += self.betMoney3 * 2
                flag[i]=1
            else: #족보 비교
                if playerscore[i] >dealerscore:
                    self.win[i].configure(text="승")
                    if i == 0:
                        self.playerMoney += self.betMoney1 * 2
                    elif i == 1:
                        self.playerMoney += self.betMoney2 * 2
                    else:
                        self.playerMoney += self.betMoney3 * 2
                    flag[i]=1
                elif playerscore[i] <dealerscore:
                    self.win[i].configure(text="패")
                    flag[i]=-1
                else:
                    self.win[i].configure(text="무")
                    if i == 0:
                        self.playerMoney += self.betMoney1
                    elif i == 1:
                        self.playerMoney += self.betMoney2
                    else:
                        self.playerMoney += self.betMoney3
        if 1 in flag:
            PlaySound('sounds/win.wav', SND_FILENAME)
        elif -1 in flag:
            PlaySound('sounds/wrong.wav', SND_FILENAME)

        self.betMoney1 = 0
        self.betMoney2 = 0
        self.betMoney3 = 0
        self.LplayerMoney.configure(text="$"+str(self.playerMoney))
        self.LbetMoney1.configure(text="$"+str(self.betMoney1))
        self.LbetMoney2.configure(text="$" + str(self.betMoney2))
        self.LbetMoney3.configure(text="$" + str(self.betMoney3))

        self.p1_1['state'] = 'disabled'
        self.p1_1['bg'] = 'gray'
        self.p2_1['state'] = 'disabled'
        self.p2_1['bg'] = 'gray'
        self.p3_1['state'] = 'disabled'
        self.p3_1['bg'] = 'gray'
        self.p1_5['state'] = 'disabled'
        self.p1_5['bg'] = 'gray'
        self.p2_5['state'] = 'disabled'
        self.p2_5['bg'] = 'gray'
        self.p3_5['state'] = 'disabled'
        self.p3_5['bg'] = 'gray'

        self.Deal['state'] = 'disabled'
        self.Deal['bg'] = 'gray'
        self.Again['state'] = 'active'
        self.Again['bg'] = 'white'

BlackJack()